package jdp3e.null_object.implementation1;

interface Vehicle {
	void travel();
}
