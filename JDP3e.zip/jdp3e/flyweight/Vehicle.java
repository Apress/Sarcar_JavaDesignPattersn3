package jdp3e.flyweight;

interface Vehicle {
	// Color comes from client. It is extrinsic.
	void aboutMe(String color);
}
