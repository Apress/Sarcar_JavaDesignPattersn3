package jdp3e.proxy.implementation_2.components;

// Abstract class Subject
public abstract class Subject
{
	public abstract void doSomeWork(String user);
}
