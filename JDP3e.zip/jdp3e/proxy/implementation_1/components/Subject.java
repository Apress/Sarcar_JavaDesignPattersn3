package jdp3e.proxy.implementation_1.components;

// The abstract class Subject
public abstract class Subject {
	public abstract void doSomeWork();
}
