package jdp3e.simplefactory;

interface Animal{
    void displayBehavior();
}
