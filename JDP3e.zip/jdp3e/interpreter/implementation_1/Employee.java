package jdp3e.interpreter.implementation_1;

interface Employee {
	public boolean interpret(Context context);
}
