package jdp3e.interpreter.implementation_2;

interface Employee {
	public boolean interpret(Context context);
}