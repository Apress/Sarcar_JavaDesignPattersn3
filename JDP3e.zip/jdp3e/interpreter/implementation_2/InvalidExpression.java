package jdp3e.interpreter.implementation_2;

class InvalidExpression {

}
