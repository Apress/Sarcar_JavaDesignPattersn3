package jdp3e.observer.implementation_1;

interface Observer {
	void getNotification(Company company);	
	String getObserverName();
}
