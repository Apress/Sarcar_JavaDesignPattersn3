package jdp3e.iterator.implementation_3;

import java.util.Iterator;

interface Database {
	Iterator<Employee> createIterator();
}
