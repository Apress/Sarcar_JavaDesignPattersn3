package jdp3e.iterator.implementation_1;

interface Department {
	
	Iterator createIterator();

}
