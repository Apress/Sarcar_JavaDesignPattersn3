package jdp3e.iterator.implementation_2;

import java.util.Iterator;

interface Department {
	Iterator<String> createIterator();	
}
