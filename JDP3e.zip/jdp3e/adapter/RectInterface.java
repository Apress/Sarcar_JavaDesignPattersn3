package jdp3e.adapter;

interface RectInterface {
	
	void aboutMe();
	double calculateArea();
}
