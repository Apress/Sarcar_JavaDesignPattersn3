package jdp3e.adapter.implementation_2;

interface TriInterface {
	
    void aboutTriangle();
}
