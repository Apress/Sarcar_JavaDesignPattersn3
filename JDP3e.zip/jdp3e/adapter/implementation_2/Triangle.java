package jdp3e.adapter.implementation_2;

class Triangle implements TriInterface {
	
    public void aboutTriangle() {
    	System.out.println("Shape type: Triangle.");
    }
}