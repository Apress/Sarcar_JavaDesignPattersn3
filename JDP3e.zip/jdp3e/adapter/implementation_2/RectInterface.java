package jdp3e.adapter.implementation_2;

interface RectInterface {
    void aboutMe();
}
