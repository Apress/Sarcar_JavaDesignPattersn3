package jdp3e.adapter.implementation_2;

class Rectangle implements RectInterface {
    public void aboutMe() {
    	System.out.println("Shape type: Rectangle.");
    }
}