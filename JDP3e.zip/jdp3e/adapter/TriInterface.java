package jdp3e.adapter;

interface TriInterface {
	
	void aboutTriangle();
	double calculateTriangleArea();
}
