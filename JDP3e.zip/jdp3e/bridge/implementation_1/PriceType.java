package jdp3e.bridge.implementation_1;

// Implementor
interface PriceType {

	void displayProductPrice(String product,double cost);

}


