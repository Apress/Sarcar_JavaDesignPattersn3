package jdp3e.abstractfactory;

//Abstract Product-1
public interface Tiger
{
  void aboutMe();
  void inviteDog(Dog dog);
}

