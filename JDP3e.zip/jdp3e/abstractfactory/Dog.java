package jdp3e.abstractfactory;

//Abstract Product-2
public interface Dog
{
 void displayMe();
}