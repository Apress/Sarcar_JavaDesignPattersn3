package jdp3e.strategy;

// Abstract Behavior

interface VehicleBehavior {
	void showDetail(Vehicle vehicle);
}
