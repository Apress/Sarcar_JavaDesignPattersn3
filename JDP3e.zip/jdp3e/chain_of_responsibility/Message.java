package jdp3e.chain_of_responsibility;

class Message {

	public String text;

	public Message(String msg) {
		text = msg;

	}
}
