package jdp3e.visitor.implementation_3;

interface Visitor {
	void visitTheElement(SeniorEmployee employees);
	void visitTheElement(JuniorEmployee employee);	
}

