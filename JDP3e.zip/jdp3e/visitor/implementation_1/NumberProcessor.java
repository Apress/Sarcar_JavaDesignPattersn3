package jdp3e.visitor.implementation_1;

interface NumberProcessor {	
	void acceptVisitor(Visitor visitor);
}
