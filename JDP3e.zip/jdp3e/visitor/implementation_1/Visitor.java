package jdp3e.visitor.implementation_1;

interface Visitor {
	// The method to visit the IntegerProcessor.
	void visitNumber(IntegerProcessor myInt);
}