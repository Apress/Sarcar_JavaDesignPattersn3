package jdp3e.factorymethod.implementation_2;

interface Animal{
    void displayBehavior();
}

