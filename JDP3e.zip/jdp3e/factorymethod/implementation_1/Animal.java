package jdp3e.factorymethod.implementation_1;

interface Animal{
    void displayBehavior();
}
