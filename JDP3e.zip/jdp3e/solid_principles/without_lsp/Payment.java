package jdp3e.solid_principles.without_lsp;

interface Payment {

	void previousPaymentInfo();

	void newPayment();
}