package jdp3e.solid_principles.lsp;

interface NewPayment {

	void newPayment();

}
