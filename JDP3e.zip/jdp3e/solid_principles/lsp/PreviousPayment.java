package jdp3e.solid_principles.lsp;

interface PreviousPayment {
	
	void previousPaymentInfo();

}
