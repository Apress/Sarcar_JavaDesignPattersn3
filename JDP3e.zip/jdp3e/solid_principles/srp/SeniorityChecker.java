package jdp3e.solid_principles.srp;

class SeniorityChecker {
    public String checkSeniority(double experienceInYears){
    	 return  experienceInYears > 5 ?"senior":"junior";  
    }
}
