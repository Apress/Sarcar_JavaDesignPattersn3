package jdp3e.solid_principles.ocp;

interface DistinctionDecider {
	void evaluateDistinction(Student student);
}
