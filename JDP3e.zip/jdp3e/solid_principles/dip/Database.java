package jdp3e.solid_principles.dip;

interface Database {
	void saveEmpIdInDatabase(String empId);
}
