package jdp3e.solid_principles.isp;

interface FaxDevice {
	
	void sendFax();

}
