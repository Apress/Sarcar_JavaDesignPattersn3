package jdp3e.solid_principles.isp;


class BasicPrinter implements Printer {
	@Override
	public void printDocument() {
		System.out.println("The basic printer prints a document.");
	}

}

