package jdp3e.solid_principles.without_isp;

interface Printer {
	
	void printDocument();

	void sendFax();
}